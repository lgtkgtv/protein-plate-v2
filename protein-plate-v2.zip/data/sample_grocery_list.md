# Grocery List

Generated from the [7-day meal plan](meal-plan.md) — one week, family of 4. Tick items off as you shop.

## Vegetables, fruit & herbs

- [ ] Bell pepper / capsicum — 9 piece
- [ ] Bottle gourd (lauki) — 2 piece
- [ ] Broccoli — 1.1 kg
- [ ] Cabbage — 400 g
- [ ] Cherry tomato — 300 g
- [ ] Coriander (fresh) — 2¼ cup + 2 handful
- [ ] Cucumber — 6½ piece
- [ ] Curry leaves — 1 sprig
- [ ] Garlic — 15 clove
- [ ] Ginger — 1 tsp
- [ ] Ginger-garlic paste — 5 tbsp  *(Buy a jar, or blend fresh ginger + garlic.)*
- [ ] Green chilli — 6 piece
- [ ] Lemon / lime — 5 tbsp + 4½ piece
- [ ] Lettuce — 3 head
- [ ] Mint (fresh) — 8 tbsp
- [ ] Mushroom — 450 g
- [ ] Onion — 20½ piece
- [ ] Spinach — 500 g + 3 handful
- [ ] Tomato — 14½ piece

## Proteins & dairy

- [ ] Boiled chickpeas / chana — 4½ cup  *(Buy dry chana (cheapest) or canned chickpeas.)*
- [ ] Boneless chicken — 1.6 kg
- [ ] Curd / yogurt — 6½ cup
- [ ] Eggs — 16 piece
- [ ] Moong sprouts — 3 cup  *(Buy dry green moong and sprout at home — sprouting ~triples the volume.)*
- [ ] Paneer — 1 kg

## Nuts & seeds

- [ ] Almonds — 250 g
- [ ] Mixed nuts — 3 tbsp
- [ ] Mixed seeds — 6 tbsp  *(Pumpkin + sunflower + flax mix.)*
- [ ] Pumpkin seeds — 200 g
- [ ] Sunflower seeds — 150 g
- [ ] Walnuts — 250 g

## Flours & dals

- [ ] Besan (gram flour) — 4¼ cup

## Fats & oils

- [ ] Cooking oil (groundnut/mustard) — ¾ cup
- [ ] Olive oil — 5 tbsp

## Pantry & spices

- [ ] Ajwain (carom seeds) — 1 tsp
- [ ] Amchur (dry mango powder) — ½ tsp
- [ ] Black pepper — 1 tsp
- [ ] Chaat masala — 1 tbsp
- [ ] Chilli flakes — 1 tsp
- [ ] Coriander powder — 1 tsp
- [ ] Cumin powder — 1½ tbsp
- [ ] Cumin seeds (jeera) — 2 tsp
- [ ] Garam masala — 1 tbsp
- [ ] Kashmiri chilli powder — 1½ tsp
- [ ] Kasuri methi (dried fenugreek) — 1½ tsp
- [ ] Mustard seeds — 2 tsp
- [ ] Red chilli powder — 2 tbsp
- [ ] Turmeric — 1 tbsp
- [ ] Salt — to taste / as needed

## Condiments / other

- [ ] Tahini (sesame paste) — 2 tbsp

