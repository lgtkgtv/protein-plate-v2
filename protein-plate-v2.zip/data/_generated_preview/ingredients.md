# Ingredients & Portions

Each dish mapped to its raw ingredients, then a summary of which ingredients recur most across the menu. Auto-generated from the data.

## Protein anchors

- **Boiled eggs** — 8 Eggs · Water to cover
- **Chana / chickpea masala** — 3 cup Boiled chickpeas / chana · 2 Onion (chopped) · 2 Tomato (pureed) · 1 tbsp Ginger-garlic paste · ½ tsp Turmeric · 1 tsp Red chilli powder · 1 tsp Coriander powder · 1 tsp Cumin powder · 1 tsp Garam masala · ½ tsp Amchur (dry mango powder) · 2 tbsp Cooking oil (groundnut/mustard) · Salt to taste · 2 tbsp Coriander (fresh) (chopped) *(optional)* · 1 cup Water
- **Chicken tikka on tawa** — 900 g Boneless chicken (cubed) · ¾ cup Curd / yogurt (hung) · 1½ tbsp Ginger-garlic paste · 2 tbsp Lemon / lime · 1½ tsp Kashmiri chilli powder · ½ tsp Turmeric · 1 tsp Garam masala · 1 tsp Chaat masala · 1 tsp Kasuri methi (dried fenugreek) · 2 tbsp Besan (gram flour) (roasted) · 1 tbsp Cooking oil (groundnut/mustard) · Salt to taste
- **Chicken-vegetable stir-fry** — 700 g Boneless chicken (cubed) · 200 g Broccoli (florets) · 1 Bell pepper / capsicum (sliced) · 100 g Cabbage (shredded) · 1 Onion (sliced) · 1 Cucumber (sliced) · 1 tbsp Ginger-garlic paste · 1 tsp Black pepper · 1 tsp Chilli flakes · 1 tbsp Cooking oil (groundnut/mustard) · Salt to taste
- **Egg bhurji** — 8 Eggs (beaten) · 2 Onion (chopped) · 2 Tomato (chopped) · 1 Green chilli (chopped) · 1 tsp Ginger-garlic paste · ½ tsp Turmeric · 1 tsp Red chilli powder · ½ tsp Garam masala · 1 tbsp Cooking oil (groundnut/mustard) · Salt to taste · 2 tbsp Coriander (fresh) (chopped) *(optional)*
- **Grilled paneer on tawa** — 500 g Paneer (cubed or sliced) · ½ cup Curd / yogurt (thick) · 1 tsp Red chilli powder · ½ tsp Turmeric · ½ tsp Garam masala · ½ tsp Chaat masala · ½ tsp Kasuri methi (dried fenugreek) · 2 tsp Besan (gram flour) (roasted) · 1 tbsp Lemon / lime · 1 tsp Ginger-garlic paste · 1 tsp Cooking oil (groundnut/mustard) · Salt to taste
- **Moong sprouts usal** — 3 cup Moong sprouts · 1 Onion (chopped) · 1 Tomato (chopped) · 1 tsp Ginger-garlic paste · 1 Green chilli (slit) · 1 tsp Mustard seeds · 1 tsp Cumin seeds (jeera) · ½ tsp Turmeric · 1 tsp Red chilli powder · 1 sprig Curry leaves *(optional)* · 1 tbsp Cooking oil (groundnut/mustard) · Salt to taste · 2 tbsp Coriander (fresh) (chopped) *(optional)* · ½ Lemon / lime *(optional)* · ½ cup Water
- **Paneer bhurji** — 500 g Paneer (crumbled) · 2 Onion (chopped) · 2 Tomato (chopped) · 1 Bell pepper / capsicum (chopped) · 1 Green chilli (chopped) · 1 tsp Ginger-garlic paste · ½ tsp Turmeric · 1 tsp Red chilli powder · ½ tsp Garam masala · 1 tbsp Cooking oil (groundnut/mustard) · Salt to taste · 2 tbsp Coriander (fresh) (chopped) *(optional)*
- **Vegetable omelette** — 8 Eggs · 1 Onion (chopped) · 1 Tomato (chopped) · 1 Bell pepper / capsicum (chopped) · 1 handful Spinach (chopped) · 1 Green chilli (chopped) · ¼ tsp Turmeric · Salt to taste · ½ tsp Ghee

## The binder

- **Besan / moong cheela** — 2 cup Besan (gram flour) · 1 Onion (finely chopped) · 1 Tomato (finely chopped) · ½ Bell pepper / capsicum (finely chopped) · 1 handful Coriander (fresh) (chopped) · 1 Green chilli (chopped) · ½ tsp Ajwain (carom seeds) · ¼ tsp Turmeric · Salt to taste · 2 tsp Cooking oil (groundnut/mustard) · Water as needed

## Daily sides

- **Green soup** — 1 Bottle gourd (lauki) (chopped) · 1 Onion (chopped) · 2 clove Garlic · Black pepper to taste · Salt to taste · 1 tbsp Curd / yogurt *(optional)* · 3 cup Water
- **Sauteed greens / bean sabzi** — 250 g Spinach (chopped) · 2 clove Garlic (chopped) · ½ tsp Red chilli powder · ½ tsp Mustard seeds *(optional)* · ½ tsp Cumin seeds (jeera) *(optional)* · 1 tbsp Cooking oil (groundnut/mustard) · Salt to taste
- **Sauteed mixed vegetables** — 200 g Broccoli (florets) · 1 Bell pepper / capsicum (sliced) · 150 g Mushroom (sliced) · 1 Onion (sliced) · 2 clove Garlic (chopped) · 1 tbsp Mixed seeds · 1 tbsp Cooking oil (groundnut/mustard) · Salt to taste

## Salads (no/low cooking)

- **Big leafy salad** — 1 head Lettuce (torn) · 100 g Cabbage (shredded) · 1 handful Spinach · 100 g Broccoli (small florets) · 1 Bell pepper / capsicum (sliced) · 100 g Cherry tomato · 1 tbsp Mixed seeds · 1 tbsp Mixed nuts · ½ Lemon / lime · 1 tbsp Olive oil
- **Curd vegetable salad / raita** — 1 cup Curd / yogurt (whisked) · ½ Tomato (diced) · ½ Cucumber (diced) · ½ Onion (diced) · ½ tsp Cumin powder (roasted) · Salt to taste · 1 tbsp Coriander (fresh) (chopped) *(optional)*
- **Kachumber salad** — 1 Tomato (diced) · 1 Cucumber (diced) · 1 Onion (diced) · 1 tbsp Coriander (fresh) (chopped) · ½ Lemon / lime · ½ tsp Chaat masala

## Condiments & extras

- **Buttermilk (chaas)** — ½ cup Curd / yogurt · 1½ cup Water · ¼ tsp Cumin powder (roasted) · Salt to taste · 1 tbsp Coriander (fresh) (chopped) *(optional)*
- **Green chutney** — 1 cup Coriander (fresh) · ½ cup Mint (fresh) · 1 Green chilli · 1 tsp Ginger · ½ Lemon / lime · Salt to taste
- **Hummus** — 1½ cup Boiled chickpeas / chana · 2 tbsp Tahini (sesame paste) · 1 clove Garlic · 2 tbsp Lemon / lime · 2 tbsp Olive oil · ½ tsp Cumin powder · Salt to taste · Water as needed
- **Toasted nuts & seeds** — 250 g Almonds · 250 g Walnuts · 200 g Pumpkin seeds · 150 g Sunflower seeds

## Recurring ingredients

How many recipes use each ingredient — your highest-leverage staples.

| Ingredient | Used in (recipes) |
| --- | --- |
| Salt | 16 |
| Onion | 11 |
| Cooking oil (groundnut/mustard) | 10 |
| Coriander (fresh) | 9 |
| Tomato | 8 |
| Turmeric | 8 |
| Ginger-garlic paste | 7 |
| Lemon / lime | 7 |
| Water | 7 |
| Bell pepper / capsicum | 6 |
| Green chilli | 6 |
| Red chilli powder | 6 |
| Curd / yogurt | 5 |
| Garam masala | 5 |
| Cumin powder | 4 |
| Garlic | 4 |
| Besan (gram flour) | 3 |
| Broccoli | 3 |
| Chaat masala | 3 |
| Cucumber | 3 |
| Eggs | 3 |
| Spinach | 3 |

