# 7-Day Meal Plan

A decision-free week for a family of 4. Each plate = a protein anchor + a cooked veg + a salad + extras. Generated from the data, so it stays in sync with the recipes and the grocery list.

| Day | Protein anchor | Cooked veg | Salad | Extras |
| --- | --- | --- | --- | --- |
| Monday | Chicken tikka on tawa | Sauteed mixed vegetables | Kachumber salad | Buttermilk (chaas), Toasted nuts & seeds |
| Tuesday | Paneer bhurji | Sauteed greens / bean sabzi | Big leafy salad | Green chutney, Toasted nuts & seeds |
| Wednesday | Egg bhurji | Green soup | Curd vegetable salad / raita | Toasted nuts & seeds |
| Thursday | Chana / chickpea masala | Sauteed mixed vegetables | Kachumber salad | Buttermilk (chaas), Toasted nuts & seeds |
| Friday | Grilled paneer on tawa | Sauteed mixed vegetables | Big leafy salad | Hummus, Toasted nuts & seeds |
| Saturday | Chicken-vegetable stir-fry | Green soup | Curd vegetable salad / raita | Buttermilk (chaas), Toasted nuts & seeds |
| Sunday | Moong sprouts usal | Sauteed greens / bean sabzi | Big leafy salad | Besan / moong cheela, Green chutney, Toasted nuts & seeds |

## Cook once, eat through the week

The plan above works because most of it is batch-prepped. Number of batches to cook this week:

| Recipe | Batches | Keeps |
| --- | --- | --- |
| Besan / moong cheela | 2 | Cook fresh. |
| Big leafy salad | 3 | Dress just before eating. |
| Boiled eggs | 1 | Fridge 7 days · Keep in shell, fridge 5-7 days. |
| Buttermilk (chaas) | 4 | Fridge 1 day |
| Chana / chickpea masala | 1 | Fridge 5 days · Freeze 30 days |
| Chicken tikka on tawa | 1 | Fridge 3 days · Freeze 30 days · Freeze raw in marinade up to 1 month (thaw overnight); cooked keeps 3 days. |
| Chicken-vegetable stir-fry | 1 | Fridge 3 days |
| Curd vegetable salad / raita | 3 | Fridge 1 day |
| Egg bhurji | 1 | Fridge 2 days |
| Green chutney | 1 | Fridge 4 days · Freeze 30 days · Freezes well in ice-cube trays. |
| Green soup | 2 | Fridge 3 days · Freeze 30 days |
| Grilled paneer on tawa | 1 | Cook fresh for best texture. |
| Hummus | 1 | Fridge 5 days |
| Kachumber salad | 4 | Eat fresh. |
| Moong sprouts usal | 1 | Fridge 3 days |
| Paneer bhurji | 1 | Fridge 2 days |
| Sauteed greens / bean sabzi | 2 | Fridge 2 days |
| Sauteed mixed vegetables | 3 | Fridge 2 days |
| Toasted nuts & seeds | 1 | Airtight jar, keeps for weeks. |

