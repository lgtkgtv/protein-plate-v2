# Recipes

Every recipe is scaled for a **family of 4** and generated from the [recipe data](https://github.com/lgtkgtv/protein-plate-v2/tree/main/data). Pick one protein anchor, then add a cooked veg, a salad, dairy and nuts/seeds.

## Protein anchors

### Boiled eggs

**Ingredients (4):** 8 Eggs · Water to cover

1. Cover eggs with water, boil 8-9 min.
2. Ice-bath, then peel.

🧊 Fridge 7 days · Keep in shell, fridge 5-7 days. · 💡 2 eggs per person is a typical serving.

### Chana / chickpea masala

**Ingredients (4):** 3 cup Boiled chickpeas / chana · 2 Onion (chopped) · 2 Tomato (pureed) · 1 tbsp Ginger-garlic paste · ½ tsp Turmeric · 1 tsp Red chilli powder · 1 tsp Coriander powder · 1 tsp Cumin powder · 1 tsp Garam masala · ½ tsp Amchur (dry mango powder) · 2 tbsp Cooking oil (groundnut/mustard) · Salt to taste · 2 tbsp Coriander (fresh) (chopped) *(optional)* · 1 cup Water

1. Saute onion till deep golden; add ginger-garlic, then tomato puree + spices; cook till oil separates.
2. Add chickpeas + 1 cup water; simmer 10-15 min; mash a few to thicken.
3. Finish with garam masala, amchur and coriander.

🎥 [video](https://www.indianhealthyrecipes.com/chana-masala/) · 🧊 Fridge 5 days · Freeze 30 days · 💡 Make a double batch of the onion-tomato masala base and freeze it — it becomes the base for chana, paneer or egg dishes in minutes.

### Chicken tikka on tawa

**Ingredients (4):** 900 g Boneless chicken (cubed) · ¾ cup Curd / yogurt (hung) · 1½ tbsp Ginger-garlic paste · 2 tbsp Lemon / lime · 1½ tsp Kashmiri chilli powder · ½ tsp Turmeric · 1 tsp Garam masala · 1 tsp Chaat masala · 1 tsp Kasuri methi (dried fenugreek) · 2 tbsp Besan (gram flour) (roasted) · 1 tbsp Cooking oil (groundnut/mustard) · Salt to taste

1. First marinade: chicken + lemon + ginger-garlic + salt, 30 min.
2. Second marinade: add hung curd + spices + besan + oil; rest 1 hr, ideally overnight.
3. Sear on a hot tawa/cast-iron, single layer, 4-5 min per side until charred and cooked through (no pink, ~75 C internal). Work in batches.

🎥 [video](https://www.youtube.com/watch?v=8L7V1eTaTnw) · 🧊 Fridge 3 days · Freeze 30 days · Freeze raw in marinade up to 1 month (thaw overnight); cooked keeps 3 days. · 💡 Hung curd makes the chicken sear instead of steam.

### Chicken-vegetable stir-fry

**Ingredients (4):** 700 g Boneless chicken (cubed) · 200 g Broccoli (florets) · 1 Bell pepper / capsicum (sliced) · 100 g Cabbage (shredded) · 1 Onion (sliced) · 1 Cucumber (sliced) · 1 tbsp Ginger-garlic paste · 1 tsp Black pepper · 1 tsp Chilli flakes · 1 tbsp Cooking oil (groundnut/mustard) · Salt to taste

1. Sear chicken first till golden, remove.
2. Stir-fry hard veg on high 3-4 min, then quick-cooking veg.
3. Return chicken; toss with pepper, chilli flakes and salt.

🧊 Fridge 3 days · 💡 High heat + don't crowd the pan = sear, not steam.

### Egg bhurji

**Ingredients (4):** 8 Eggs (beaten) · 2 Onion (chopped) · 2 Tomato (chopped) · 1 Green chilli (chopped) · 1 tsp Ginger-garlic paste · ½ tsp Turmeric · 1 tsp Red chilli powder · ½ tsp Garam masala · 1 tbsp Cooking oil (groundnut/mustard) · Salt to taste · 2 tbsp Coriander (fresh) (chopped) *(optional)*

1. Build the onion-tomato masala base; cook till soft.
2. Pour beaten eggs at the end; scramble on medium-low (high heat = rubbery).
3. Pull off heat while slightly underdone.

🎥 [video](https://www.youtube.com/watch?v=1OdPf65aPJg) · 🧊 Fridge 2 days · 💡 Reuse the same masala base from chana for a fast meal.

### Grilled paneer on tawa

**Ingredients (4):** 500 g Paneer (cubed or sliced) · ½ cup Curd / yogurt (thick) · 1 tsp Red chilli powder · ½ tsp Turmeric · ½ tsp Garam masala · ½ tsp Chaat masala · ½ tsp Kasuri methi (dried fenugreek) · 2 tsp Besan (gram flour) (roasted) · 1 tbsp Lemon / lime · 1 tsp Ginger-garlic paste · 1 tsp Cooking oil (groundnut/mustard) · Salt to taste

1. Whisk the marinade; coat paneer; rest 30 min (no longer — acid makes paneer rubbery).
2. Sear on a medium-high, lightly oiled tawa 3-4 min per side until charred. Don't move it constantly.

🎥 [video](https://www.youtube.com/watch?v=BwIJHI4KdIE) · 🧊 Cook fresh for best texture. · 💡 Sear marinated capsicum and onion alongside.

### Moong sprouts usal

**Ingredients (4):** 3 cup Moong sprouts · 1 Onion (chopped) · 1 Tomato (chopped) · 1 tsp Ginger-garlic paste · 1 Green chilli (slit) · 1 tsp Mustard seeds · 1 tsp Cumin seeds (jeera) · ½ tsp Turmeric · 1 tsp Red chilli powder · 1 sprig Curry leaves *(optional)* · 1 tbsp Cooking oil (groundnut/mustard) · Salt to taste · 2 tbsp Coriander (fresh) (chopped) *(optional)* · ½ Lemon / lime *(optional)* · ½ cup Water

1. Heat oil; splutter mustard + cumin, add curry leaves, onion, ginger-garlic and chilli — saute till golden.
2. Add tomato + dry spices; cook till soft.
3. Add sprouts + 1/2 cup water, cover, simmer 8-10 min (keep some crunch).
4. Finish with coriander and a squeeze of lemon.

🎥 [video](https://www.youtube.com/watch?v=u33FYQVfZ68) · 🧊 Fridge 3 days · 💡 Steam sprouts first for a softer texture.

### Paneer bhurji

**Ingredients (4):** 500 g Paneer (crumbled) · 2 Onion (chopped) · 2 Tomato (chopped) · 1 Bell pepper / capsicum (chopped) · 1 Green chilli (chopped) · 1 tsp Ginger-garlic paste · ½ tsp Turmeric · 1 tsp Red chilli powder · ½ tsp Garam masala · 1 tbsp Cooking oil (groundnut/mustard) · Salt to taste · 2 tbsp Coriander (fresh) (chopped) *(optional)*

1. Saute onion -> ginger-garlic -> capsicum -> tomato + spices till soft.
2. Add crumbled paneer, toss 3-4 min, finish with coriander.

🧊 Fridge 2 days · 💡 Same recipe with eggs instead of paneer = egg bhurji.

### Vegetable omelette

**Ingredients (4):** 8 Eggs · 1 Onion (chopped) · 1 Tomato (chopped) · 1 Bell pepper / capsicum (chopped) · 1 handful Spinach (chopped) · 1 Green chilli (chopped) · ¼ tsp Turmeric · Salt to taste · ½ tsp Ghee

1. Beat eggs with chopped vegetables, chilli, salt and turmeric.
2. Cook on a little ghee, flip once.

🧊 Cook fresh.

## The binder

### Besan / moong cheela

**Ingredients (4):** 2 cup Besan (gram flour) · 1 Onion (finely chopped) · 1 Tomato (finely chopped) · ½ Bell pepper / capsicum (finely chopped) · 1 handful Coriander (fresh) (chopped) · 1 Green chilli (chopped) · ½ tsp Ajwain (carom seeds) · ¼ tsp Turmeric · Salt to taste · 2 tsp Cooking oil (groundnut/mustard) · Water as needed

1. Mix besan, vegetables and spices with water to a pourable batter; rest 10 min.
2. On a hot tawa pour a ladle, spread thin, drizzle oil, flip when edges lift.
3. Serve with green chutney.

🎥 [video](https://www.youtube.com/watch?v=8qUJOvPkpl8) · 🧊 Cook fresh. · 💡 Add 2-3 tbsp sattu or crumbled paneer to push protein higher. · 💡 Alternative base: 1.5 cups soaked-and-ground moong dal instead of besan.

## Daily sides

### Green soup

**Ingredients (4):** 1 Bottle gourd (lauki) (chopped) · 1 Onion (chopped) · 2 clove Garlic · Black pepper to taste · Salt to taste · 1 tbsp Curd / yogurt *(optional)* · 3 cup Water

1. Boil chopped lauki (or spinach/broccoli) with onion + garlic till soft (~10 min).
2. Blend, season with pepper and salt, finish with a spoon of curd or milk.

🧊 Fridge 3 days · Freeze 30 days · 💡 Make a big batch — it freezes well.

### Sauteed greens / bean sabzi

**Ingredients (4):** 250 g Spinach (chopped) · 2 clove Garlic (chopped) · ½ tsp Red chilli powder · ½ tsp Mustard seeds *(optional)* · ½ tsp Cumin seeds (jeera) *(optional)* · 1 tbsp Cooking oil (groundnut/mustard) · Salt to taste

1. Greens version: garlic + spinach/methi wilted 2-3 min with salt and chilli.
2. Bean version: beans/capsicum with mustard-cumin tempering, 6-8 min covered.

🧊 Fridge 2 days · 💡 Swap spinach for methi, green beans or capsicum using the same method.

### Sauteed mixed vegetables

**Ingredients (4):** 200 g Broccoli (florets) · 1 Bell pepper / capsicum (sliced) · 150 g Mushroom (sliced) · 1 Onion (sliced) · 2 clove Garlic (chopped) · 1 tbsp Mixed seeds · 1 tbsp Cooking oil (groundnut/mustard) · Salt to taste

1. Hot pan: garlic + onion 1 min -> broccoli + capsicum 3-4 min -> mushroom 2 min.
2. Season; finish with mixed seeds. Keep it crisp-tender.

🧊 Fridge 2 days

## Salads (no/low cooking)

### Big leafy salad

**Ingredients (4):** 1 head Lettuce (torn) · 100 g Cabbage (shredded) · 1 handful Spinach · 100 g Broccoli (small florets) · 1 Bell pepper / capsicum (sliced) · 100 g Cherry tomato · 1 tbsp Mixed seeds · 1 tbsp Mixed nuts · ½ Lemon / lime · 1 tbsp Olive oil

1. Toss leaves and vegetables; top with seeds and nuts; dress with lemon + olive oil.

🧊 Dress just before eating. · 💡 Store washed-and-dried greens with a paper towel in an airtight box; moisture is what makes salad slimy.

### Curd vegetable salad / raita

**Ingredients (4):** 1 cup Curd / yogurt (whisked) · ½ Tomato (diced) · ½ Cucumber (diced) · ½ Onion (diced) · ½ tsp Cumin powder (roasted) · Salt to taste · 1 tbsp Coriander (fresh) (chopped) *(optional)*

1. Fold diced vegetables into whisked curd with roasted cumin and salt.

🧊 Fridge 1 day

### Kachumber salad

**Ingredients (4):** 1 Tomato (diced) · 1 Cucumber (diced) · 1 Onion (diced) · 1 tbsp Coriander (fresh) (chopped) · ½ Lemon / lime · ½ tsp Chaat masala

1. Combine equal tomato, cucumber and onion with coriander, lemon and chaat masala.
2. Dress just before eating.

🧊 Eat fresh. · 💡 Salt/dress last — salt pulls out water and makes it soggy.

## Condiments & extras

### Buttermilk (chaas)

**Ingredients (4):** ½ cup Curd / yogurt · 1½ cup Water · ¼ tsp Cumin powder (roasted) · Salt to taste · 1 tbsp Coriander (fresh) (chopped) *(optional)*

1. Whisk curd + water + roasted cumin + salt + coriander until frothy.

🧊 Fridge 1 day

### Green chutney

**Ingredients (8):** 1 cup Coriander (fresh) · ½ cup Mint (fresh) · 1 Green chilli · 1 tsp Ginger · ½ Lemon / lime · Salt to taste

1. Blend coriander + mint + green chilli + ginger + lemon + salt to a smooth chutney.

🧊 Fridge 4 days · Freeze 30 days · Freezes well in ice-cube trays.

### Hummus

**Ingredients (6):** 1½ cup Boiled chickpeas / chana · 2 tbsp Tahini (sesame paste) · 1 clove Garlic · 2 tbsp Lemon / lime · 2 tbsp Olive oil · ½ tsp Cumin powder · Salt to taste · Water as needed

1. Blend boiled chickpeas + tahini + garlic + lemon + olive oil + salt + cumin with a little water until smooth.

🧊 Fridge 5 days

### Toasted nuts & seeds

**Ingredients (30):** 250 g Almonds · 250 g Walnuts · 200 g Pumpkin seeds · 150 g Sunflower seeds

1. Dry-toast nuts and seeds in batches until fragrant; cool fully; store in a jar.
2. Portion ~25 g per person at serving time.

🧊 Airtight jar, keeps for weeks. · 💡 Pre-portion so you don't overshoot calories.

