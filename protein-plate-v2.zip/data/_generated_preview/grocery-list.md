# Grocery List

Generated from the [7-day meal plan](meal-plan.md) — one week, family of 4. Tick items off as you shop.

## Vegetables, fruit & herbs

- [ ] Bell pepper / capsicum — 9 piece
- [ ] Bottle gourd (lauki) — 2 piece
- [ ] Broccoli — 1100 g
- [ ] Cabbage — 400 g
- [ ] Cherry tomato — 300 g
- [ ] Coriander (fresh) — 1 cup
- [ ] Coriander (fresh) — 2 handful
- [ ] Coriander (fresh) — 19 tbsp
- [ ] Cucumber — 6½ piece
- [ ] Curry leaves — 1 sprig
- [ ] Garlic — 15 clove
- [ ] Ginger — 1 tsp
- [ ] Ginger-garlic paste — 3½ tbsp  *(Buy a jar, or blend fresh ginger + garlic.)*
- [ ] Ginger-garlic paste — 4 tsp  *(Buy a jar, or blend fresh ginger + garlic.)*
- [ ] Green chilli — 6 piece
- [ ] Lemon / lime — 4½ piece
- [ ] Lemon / lime — 5 tbsp
- [ ] Lettuce — 3 head
- [ ] Mint (fresh) — ½ cup
- [ ] Mushroom — 450 g
- [ ] Onion — 20½ piece
- [ ] Spinach — 500 g
- [ ] Spinach — 3 handful
- [ ] Tomato — 14½ piece

## Proteins & dairy

- [ ] Boiled chickpeas / chana — 4½ cup  *(Buy dry chana (cheapest) or canned chickpeas.)*
- [ ] Boneless chicken — 1600 g
- [ ] Curd / yogurt — 6¼ cup
- [ ] Curd / yogurt — 2 tbsp
- [ ] Eggs — 16 piece
- [ ] Moong sprouts — 3 cup  *(Buy dry green moong and sprout at home — sprouting ~triples the volume.)*
- [ ] Paneer — 1000 g

## Nuts & seeds

- [ ] Almonds — 250 g
- [ ] Mixed nuts — 3 tbsp
- [ ] Mixed seeds — 6 tbsp  *(Pumpkin + sunflower + flax mix.)*
- [ ] Pumpkin seeds — 200 g
- [ ] Sunflower seeds — 150 g
- [ ] Walnuts — 250 g

## Flours & dals

- [ ] Besan (gram flour) — 4 cup
- [ ] Besan (gram flour) — 2 tbsp
- [ ] Besan (gram flour) — 2 tsp

## Fats & oils

- [ ] Cooking oil (groundnut/mustard) — 12 tbsp
- [ ] Cooking oil (groundnut/mustard) — 5 tsp
- [ ] Olive oil — 5 tbsp

## Pantry & spices

- [ ] Ajwain (carom seeds) — 1 tsp
- [ ] Amchur (dry mango powder) — ½ tsp
- [ ] Black pepper — 1 tsp
- [ ] Chaat masala — 3½ tsp
- [ ] Chilli flakes — 1 tsp
- [ ] Coriander powder — 1 tsp
- [ ] Cumin powder — 4 tsp
- [ ] Cumin seeds (jeera) — 2 tsp
- [ ] Garam masala — 3½ tsp
- [ ] Kashmiri chilli powder — 1½ tsp
- [ ] Kasuri methi (dried fenugreek) — 1½ tsp
- [ ] Mustard seeds — 2 tsp
- [ ] Red chilli powder — 6 tsp
- [ ] Turmeric — 3½ tsp
- [ ] Salt — to taste / as needed

## Condiments / other

- [ ] Tahini (sesame paste) — 2 tbsp

